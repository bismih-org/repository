from PyQt6.QtWidgets import (
    QMainWindow,
    QVBoxLayout,
    QWidget,
    QTextEdit,
    QPushButton,
    QTextBrowser,
    QSplitter,
    QListWidget,
    QHBoxLayout,
    QListWidgetItem,
    QComboBox,
    QLabel,
)
from PyQt6.QtCore import Qt
import os

from src.common.model_loader import ModelLoader
from src.common.api_client import APIClient
from src.common.chat_manager import ChatManager
from src.ui.theme.theme_manager import ThemeManager
from src.static.config import Config


class MainWindow(QMainWindow):
    def __init__(self, x, y, message=None):
        super().__init__()
        self.setWindowTitle("Katip - YZ Sohbet Botu")
        self.setGeometry(100, 100, 1200, 700)

        self.cfg = Config()
        self._check_config_folders()
        # API ve Chat yöneticilerini başlat
        self.api_client = APIClient(cfg=self.cfg)
        self.chat_manager = ChatManager(self.api_client, cfg=self.cfg)
        self.model_loader = ModelLoader(self.cfg)

        # Chat manager sinyallerini bağla
        self.chat_manager.response_started.connect(self._on_response_started)
        self.chat_manager.partial_response.connect(self._on_partial_response)
        self.chat_manager.response_finished.connect(self._on_response_finished)
        self.chat_manager.error_occurred.connect(self._on_error_occurred)

        # Tema yöneticisi
        self.theme_manager = ThemeManager()
        self.theme_manager.apply_theme(dark_mode=True)

        # UI bileşenlerini oluştur
        self._setup_ui()

        # Mevcut YZ yanıtını takip etmek için
        self.current_response = ""
        # Sohbet içeriğini takip et
        self.full_chat_content = "# YZ Sohbet Botu (Katip)\n\nMerhaba! Size nasıl yardımcı olabilirim?\n\n---\n"

        # Sohbet geçmişi listesi
        self.chat_history_list = []
        self.current_conversation_messages = []  # Mevcut sohbetteki tüm mesajlar
        self._on_model_changed()
        if message and message[-1]== "~":
            message = message[:-1]  # Son karakteri kaldır
            self.input_text.setText(message)
            self.ask_ai()
            print(x, y, message)

    def _setup_ui(self):
        """UI bileşenlerini oluştur"""
        # Ana widget ve layout
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QHBoxLayout(self.central_widget)

        # Ana splitter (yatay)
        self.main_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.main_layout.addWidget(self.main_splitter)

        # Sol panel - Sohbet geçmişi listesi
        self.history_panel = QWidget()
        self.history_layout = QVBoxLayout(self.history_panel)

        # Sohbet geçmişi başlığı
        self.history_button = QPushButton("📋 Sohbet Geçmişi")
        self.history_button.clicked.connect(self.new_conversation)
        self.history_layout.addWidget(self.history_button)

        # Sohbet listesi
        self.history_list = QListWidget()
        self.history_list.itemClicked.connect(self.load_conversation)
        self.history_layout.addWidget(self.history_list)

        self.main_splitter.addWidget(self.history_panel)

        # Sağ panel - Ana sohbet alanı
        self.chat_panel = QWidget()
        self.chat_layout = QVBoxLayout(self.chat_panel)

        # Model seçimi paneli
        self._setup_model_selection()

        # Sohbet alanı splitter (dikey)
        self.chat_splitter = QSplitter(Qt.Orientation.Vertical)
        self.chat_layout.addWidget(self.chat_splitter)

        # Sohbet geçmişi alanı
        self.chat_history = QTextBrowser(self)
        self.chat_history.setMarkdown(
            "# YZ Sohbet Botu (Katip)\n\nMerhaba! Size nasıl yardımcı olabilirim?\n\n---\n"
        )
        self.chat_splitter.addWidget(self.chat_history)

        # Alt panel için widget
        self.input_panel = QWidget()
        self.input_layout = QVBoxLayout(self.input_panel)
        self.chat_splitter.addWidget(self.input_panel)

        # Markdown giriş alanı
        self.input_text = QTextEdit(self)
        self.input_text.setPlaceholderText("Mesajınızı yazın... (Markdown destekli)")
        self.input_layout.addWidget(self.input_text)

        # Düğme paneli
        self.button_layout = QHBoxLayout()

        # Yeni sohbet düğmesi
        self.new_chat_button = QPushButton("🆕 Yeni Sohbet")
        self.new_chat_button.clicked.connect(self.new_conversation)
        self.button_layout.addWidget(self.new_chat_button)

        # Boşluk
        self.button_layout.addStretch()

        # Durdur düğmesi (başlangıçta gizli)
        self.stop_button = QPushButton("⏹️ Durdur")
        self.stop_button.clicked.connect(self.stop_response)
        self.stop_button.setVisible(False)
        self.button_layout.addWidget(self.stop_button)

        # Gönder düğmesi
        self.send_button = QPushButton("Gönder")
        self.send_button.clicked.connect(self.ask_ai)
        self.button_layout.addWidget(self.send_button)

        self.input_layout.addLayout(self.button_layout)

        self.main_splitter.addWidget(self.chat_panel)

        # Enter tuşu ile gönderme
        self.input_text.installEventFilter(self)

        # Splitter oranlarını ayarla
        self.main_splitter.setSizes([250, 950])  # Sol panel: 250px, sağ panel: 950px
        self.chat_splitter.setSizes([500, 150])

    def _setup_model_selection(self):
        """Model seçimi panelini oluştur"""
        model_panel = QWidget()
        model_layout = QHBoxLayout(model_panel)

        # Model seçimi etiketi
        model_label = QLabel("Model:")
        model_layout.addWidget(model_label)

        # Model seçimi combobox
        self.cmb_model = QComboBox()

        # Gemini modellerini ekle
        gemini_models = ["gemini-2.5-flash", "gemini-2.0-flash"]
        for model in gemini_models:
            self.cmb_model.addItem(f"🌐 {model}", model)

        # Yerel modellerini ekle
        for model in self.model_loader.local_models:
            self.cmb_model.addItem(f"💻 {model.name}", model.name)

        # Model değiştiğinde çağrılacak fonksiyon
        self.cmb_model.currentTextChanged.connect(self._on_model_changed)

        model_layout.addWidget(self.cmb_model)
        model_layout.addStretch()

        # Model durumu etiketi
        self.model_status_label = QLabel("Model: Yüklenmedi")
        model_layout.addWidget(self.model_status_label)

        self.chat_layout.addWidget(model_panel)

    def _on_model_changed(self):
        """Model değiştiğinde çağrılır"""
        if self.cmb_model.currentData():
            selected_model = self.cmb_model.currentData()
            self.model_status_label.setText(f"Model: {selected_model} yükleniyor...")

            # Eski modeli durdur
            self.model_loader.stop_current_model()

            # Yeni modeli yükle
            try:
                self.model_loader.load_model(selected_model, self.api_client)
                self.model_status_label.setText(f"Model: {selected_model} ✅")
            except Exception as e:
                self.model_status_label.setText(f"Model: Hata - {str(e)}")

    def eventFilter(self, obj, event):
        """Ctrl+Enter ile mesaj gönderme"""
        if obj == self.input_text and event.type() == event.Type.KeyPress:
            if (
                event.key() == Qt.Key.Key_Return
                and event.modifiers() == Qt.KeyboardModifier.ControlModifier
            ):
                self.ask_ai()
                return True
        return super().eventFilter(obj, event)

    def new_conversation(self):
        """Yeni sohbet başlat"""
        self.full_chat_content = "# YZ Sohbet Botu (Katip)\n\nMerhaba! Size nasıl yardımcı olabilirim?\n\n---\n"
        self.chat_history.setMarkdown(self.full_chat_content)
        self.current_conversation_messages = []
        self.input_text.setFocus()

    def ask_ai(self):
        """AI'ya soru sor"""
        user_input = self.input_text.toPlainText().strip()
        if not user_input:
            return

        # Kullanıcı mesajını sohbet içeriğine ekle
        user_message = f"\n## 🤓 Siz:\n{user_input}\n\n## 📖 Katip:\n"
        self.full_chat_content += user_message
        self.chat_history.setMarkdown(self.full_chat_content)

        # Mesajı sohbet listesine ekle
        self.current_conversation_messages.append(
            {"role": "user", "content": user_input, "timestamp": self._get_timestamp()}
        )

        # Giriş alanını temizle
        self.input_text.clear()

        # Mesajı gönder
        self.chat_manager.send_message(user_input)

    def stop_response(self):
        """Yanıtı durdur"""
        # Chat manager'da durdurma işlemini gerçekleştir
        if hasattr(self.chat_manager, "stop_generation"):
            self.chat_manager.stop_generation()

        # Mevcut yanıtı sonlandır
        if self.current_response:
            # Yarım kalan yanıtı kaydet
            if "## 📖 Katip:\n" in self.full_chat_content:
                parts = self.full_chat_content.rsplit("## 📖 Katip:\n", 1)
                if len(parts) == 2:
                    self.full_chat_content = (
                        parts[0]
                        + "## 📖 Katip:\n"
                        + self.current_response
                        + "\n\n*[Yanıt durduruldu]*\n\n---\n"
                    )
                else:
                    self.full_chat_content += (
                        self.current_response + "\n\n*[Yanıt durduruldu]*\n\n---\n"
                    )
            else:
                self.full_chat_content += (
                    self.current_response + "\n\n*[Yanıt durduruldu]*\n\n---\n"
                )

            # Görünümü güncelle
            self.chat_history.setMarkdown(self.full_chat_content)

            # Asistan mesajını sohbet listesine ekle (durduruldu bilgisiyle)
            self.current_conversation_messages.append(
                {
                    "role": "assistant",
                    "content": self.current_response + "\n\n*[Yanıt durduruldu]*",
                    "timestamp": self._get_timestamp(),
                }
            )

            # Konuşmayı geçmişe ekle
            self._add_to_history()

        # UI'yi normal duruma getir
        self._reset_ui_state()

    def _reset_ui_state(self):
        """UI durumunu normale döndür"""
        self.send_button.setText("Gönder")
        self.send_button.setEnabled(True)
        self.stop_button.setVisible(False)
        self.input_text.setFocus()

    def _on_response_started(self):
        """Yanıt başladığında"""
        self.send_button.setText("Yanıtlanıyor...")
        self.send_button.setEnabled(False)
        self.stop_button.setVisible(True)  # Durdur butonunu göster
        self.current_response = ""

    def _on_partial_response(self, partial_result):
        """Kısmi yanıt geldiğinde"""
        self.current_response += partial_result

        # Mevcut sohbet içeriğini güncelle (son Katip: kısmını değiştir)
        if "## 📖 Katip:\n" in self.full_chat_content:
            # Son "## 📖 Katip:\n" kısmını bul
            parts = self.full_chat_content.rsplit("## 📖 Katip:\n", 1)
            if len(parts) == 2:
                updated_content = parts[0] + "## 📖 Katip:\n" + self.current_response
            else:
                updated_content = self.full_chat_content + self.current_response
        else:
            updated_content = self.full_chat_content + self.current_response

        self.chat_history.setMarkdown(updated_content)

        # Otomatik scroll
        cursor = self.chat_history.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        self.chat_history.setTextCursor(cursor)
        self.chat_history.ensureCursorVisible()

    def _on_response_finished(self):
        """Yanıt tamamlandığında"""
        # Eğer durdurma işlemi yapıldıysa bu fonksiyonu çalıştırma
        if self.chat_manager.should_stop:
            return

        # Tam yanıtı sohbet içeriğine ekle
        if "## 📖 Katip:\n" in self.full_chat_content:
            parts = self.full_chat_content.rsplit("## 📖 Katip:\n", 1)
            if len(parts) == 2:
                self.full_chat_content = (
                    parts[0] + "## 📖 Katip:\n" + self.current_response + "\n\n---\n"
                )
            else:
                self.full_chat_content += self.current_response + "\n\n---\n"
        else:
            self.full_chat_content += self.current_response + "\n\n---\n"

        # Final görünümü güncelle
        self.chat_history.setMarkdown(self.full_chat_content)

        # Asistan mesajını sohbet listesine ekle
        self.current_conversation_messages.append(
            {
                "role": "assistant",
                "content": self.current_response,
                "timestamp": self._get_timestamp(),
            }
        )

        # Konuşmayı geçmişe ekle (sadece en son soru-cevap çifti için)
        self._add_to_history()

        # UI'yi normal duruma getir
        self._reset_ui_state()

    def _on_error_occurred(self, error_message):
        """Hata oluştuğunda"""
        error_text = f"❌ **Hata:** {error_message}\n\n---\n"
        self.full_chat_content += error_text
        self.chat_history.setMarkdown(self.full_chat_content)

        # UI'yi normal duruma getir
        self._reset_ui_state()

    def _get_timestamp(self):
        """Zaman damgası oluştur"""
        from datetime import datetime

        return datetime.now().strftime("%H:%M")

    def _add_to_history(self):
        """Konuşmayı geçmiş listesine ekle"""
        if len(self.current_conversation_messages) >= 2:
            # En son soru-cevap çiftini al
            user_msg = self.current_conversation_messages[-2]
            assistant_msg = self.current_conversation_messages[-1]

            if user_msg["role"] == "user" and assistant_msg["role"] == "assistant":
                # Kısa başlık oluştur
                title = user_msg["content"][:50]
                if len(user_msg["content"]) > 50:
                    title += "..."

                # Liste öğesi oluştur
                item_text = f"{user_msg['timestamp']} - {title}"
                item = QListWidgetItem(item_text)

                # Tam konuşma verisini sakla
                conversation_data = {
                    "user": user_msg["content"],
                    "assistant": assistant_msg["content"],
                    "timestamp": user_msg["timestamp"],
                    "full_conversation": self.current_conversation_messages.copy(),
                }
                item.setData(Qt.ItemDataRole.UserRole, conversation_data)

                # Listeye ekle (en üstte görünsün)
                self.history_list.insertItem(0, item)

    def load_conversation(self, item):
        """Seçilen konuşmayı yükle"""
        conversation = item.data(Qt.ItemDataRole.UserRole)
        if conversation:
            # Eğer full_conversation varsa, tüm sohbeti yükle
            if "full_conversation" in conversation:
                self._load_full_conversation(conversation["full_conversation"])
            else:
                # Eski format için geriye dönük uyumluluk
                chat_content = f"# YZ Sohbet Botu (Katip)\n\n"
                chat_content += f"## 🤓 Siz:\n{conversation['user']}\n\n"
                chat_content += f"## 📖 Katip:\n{conversation['assistant']}\n\n---\n"

                self.full_chat_content = chat_content
                self.chat_history.setMarkdown(self.full_chat_content)

    def _load_full_conversation(self, messages):
        """Tam konuşmayı yükle"""
        chat_content = "# YZ Sohbet Botu (Katip)\n\nMerhaba! Size nasıl yardımcı olabilirim?\n\n---\n"

        for msg in messages:
            if msg["role"] == "user":
                chat_content += f"\n## 🤓 Siz:\n{msg['content']}\n\n"
            elif msg["role"] == "assistant":
                chat_content += f"## 📖 Katip:\n{msg['content']}\n\n---\n"

        self.full_chat_content = chat_content
        self.chat_history.setMarkdown(self.full_chat_content)
        self.current_conversation_messages = messages.copy()

    def _check_config_folders(self):
        """Gerekli yapılandırma klasörlerinin varlığını kontrol et"""
        if not os.path.exists(self.cfg.CONFIG_DIR):
            os.makedirs(self.cfg.CONFIG_DIR)
        if not os.path.exists(self.cfg.MODEL_PATH):
            os.makedirs(self.cfg.MODEL_PATH)
        if not os.path.isfile(self.cfg.API_KEY_FILE):
            os.system(f"touch {self.cfg.API_KEY_FILE}")
