import sys
from PyQt6.QtWidgets import QApplication

from src.ui.main_window import MainWindow

if __name__ == "__main__":
    app = QApplication(sys.argv)
    x,y,message = sys.argv[1:4]
    window = MainWindow(x,y,message)
    window.show()
    sys.exit(app.exec())
