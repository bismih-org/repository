import os


class Config:
    HOME = os.path.expanduser("~")
    CONFIG_DIR = os.path.join(HOME, ".config/katip/")
    API_KEY_FILE = CONFIG_DIR + "api_key.txt"
    MODEL_PATH = CONFIG_DIR + "model/"
    MODELS_JSON = CONFIG_DIR + "models.json"
    MAX_TOKENS = 1024
    BASE_URL = ""
    GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"
    LOCAL_URL = "http://localhost:8080/v1/"
    BASE_URL = GEMINI_URL
    MODEL = "gemini-2.5-flash"
    REASONING_EFFORT = "none"
    STREAMING = True