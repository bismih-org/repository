import threading
from PyQt6.QtCore import QObject, pyqtSignal
from src.static.config import Config


class ChatManager(QObject):
    # Sinyaller
    response_started = pyqtSignal()
    partial_response = pyqtSignal(str)
    response_finished = pyqtSignal()
    error_occurred = pyqtSignal(str)

    def __init__(self, api_client, cfg: Config):
        super().__init__()
        self.api_client = api_client
        self.cfg = cfg
        self.client = api_client.get_client()
        self.is_generating = False
        self.should_stop = False
        self.current_stream = None

    def send_message(self, message):
        """Mesaj gönder ve stream yanıt al"""
        if self.is_generating:
            return

        self.is_generating = True
        self.should_stop = False
        self.response_started.emit()

        # Thread'de çalıştır
        thread = threading.Thread(target=self._generate_response, args=(message,))
        thread.daemon = True
        thread.start()

    def _generate_response(self, message):
        """Yanıt üret (thread'de çalışır)"""
        try:
            # Client'ı yeniden al (model değiştiğinde güncellenmiş olması için)
            self.client = self.api_client.get_client()

            # Stream oluştur
            # Yerel modeller için farklı parametreler kullan
            if self.cfg.BASE_URL == self.cfg.LOCAL_URL:
                # Yerel model için
                self.current_stream = self.client.chat.completions.create(
                    model="LLaMA_CPP",  # Yerel modeller için sabit model adı
                    messages=[
                        {
                            "role": "system",
                            "content": "You are a helpful AI assistant.",
                        },
                        {"role": "user", "content": message},
                    ],
                    stream=True,
                )
            else:
                # Gemini modeller için
                self.current_stream = self.client.chat.completions.create(
                    model=self.cfg.MODEL,
                    messages=[
                        {"role": "system", "content": ""},
                        {"role": "user", "content": message},
                    ],
                    stream=True,
                    reasoning_effort=self.cfg.REASONING_EFFORT,
                )

            # Stream'i işle
            for chunk in self.current_stream:
                # Durdurma kontrolü
                if self.should_stop:
                    break

                if chunk.choices[0].delta.content:
                    content = chunk.choices[0].delta.content
                    self.partial_response.emit(content)

            # Tamamlandı sinyali gönder (sadece durdurulmadıysa)
            if not self.should_stop:
                self.response_finished.emit()

        except Exception as e:
            self.error_occurred.emit(str(e))
        finally:
            self.is_generating = False
            self.current_stream = None

    def stop_generation(self):
        """Yanıt üretimini durdur"""
        self.should_stop = True
        self.is_generating = False

        # Stream'i kapatmaya çalış
        if self.current_stream:
            try:
                # Stream'i manuel olarak kapat
                if hasattr(self.current_stream, "close"):
                    self.current_stream.close()
            except:
                pass
            finally:
                self.current_stream = None
