import json
import requests
import subprocess
import time
from pathlib import Path
from PyQt6.QtWidgets import QMessageBox, QProgressDialog
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtCore import Qt

from src.common.api_client import APIClient
from src.static.config import Config


class Model:
    def __init__(self, name: str, size: int, url: str, file_name: str, parameters: str):
        self.name = name
        self.size = size
        self.url = url
        self.file_name = file_name
        self.path = Path(f"{Config.MODEL_PATH}{file_name}")
        self.process = None  # Subprocess referansı


class DownloadThread(QThread):
    progress = pyqtSignal(int)  # İlerleme yüzdesi sinyali
    finished = pyqtSignal(bool)  # İndirme tamamlandı sinyali (başarılı/başarısız)

    def __init__(self, model: Model):
        super().__init__()
        self.model = model

    def run(self):
        """İndirme işlemini başlat"""
        model_path = self.model.path
        model_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            response = requests.get(self.model.url, stream=True)
            response.raise_for_status()

            total_size = int(response.headers.get("content-length", 0))
            downloaded_size = 0

            with open(model_path, "wb") as file:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        file.write(chunk)
                        downloaded_size += len(chunk)
                        progress = int((downloaded_size / total_size) * 100)
                        self.progress.emit(progress)

            self.finished.emit(True)  # İndirme başarılı
        except Exception as e:
            print(f"Model indirme hatası: {e}")
            if model_path.exists():
                model_path.unlink()  # Yarım kalan dosyayı sil
            self.finished.emit(False)  # İndirme başarısız


class ModelLoader:
    def __init__(self, cfg: Config, models_json_path: str = Config.MODELS_JSON):
        self.local_models = []
        self.cfg = cfg
        self.current_process = None  # Mevcut çalışan model process'i
        self.current_model = None  # Mevcut yüklü model

        with open(models_json_path, "r") as file:
            self.local_models_dict = json.load(file)
        for model in self.local_models_dict["models"]:
            m = Model(
                name=model["name"],
                size=model["size"],
                url=model["download_url"],
                file_name=model["filename"],
                parameters=model.get("parameters", ""),
            )
            self.local_models.append(m)

    def stop_current_model(self):
        """Mevcut modeli durdur"""
        if self.current_process:
            try:
                self.current_process.terminate()
                self.current_process.wait(timeout=5)  # 5 saniye bekle
            except subprocess.TimeoutExpired:
                self.current_process.kill()  # Zorla sonlandır
            except Exception as e:
                print(f"Model durdurma hatası: {e}")
            finally:
                self.current_process = None
                self.current_model = None

    def load_model(self, model_name: str, client: APIClient):
        """Modeli yükle"""
        # Önce mevcut modeli durdur
        self.stop_current_model()

        if "gemini" in model_name.lower():
            return self._load_gemini_model(model_name, client)
        else:
            return self._load_local_model(model_name, client)

    def _load_gemini_model(self, model_name: str, client: APIClient):
        """Gemini modelini yükle"""
        self.cfg.MODEL = model_name
        self.cfg.BASE_URL = self.cfg.GEMINI_URL
        self.current_model = model_name
        client.initialize_client()

    def _load_local_model(self, model_name: str, client: APIClient):
        """Yerel modelini yükle"""
        model = self.check_model(model_name)
        if not model:
            raise Exception(f"Model bulunamadı: {model_name}")

        if not model.path.exists():
            # Model yoksa kullanıcıdan onay al
            if self._show_download_dialog(model):
                self._download_model_with_progress(model)
                if not model.path.exists():  # İndirme başarısızsa
                    raise Exception("Model indirme işlemi başarısız")
            else:
                raise Exception("Model indirme işlemi iptal edildi")

        # Yerel model sunucusunu başlat
        self._start_local_model_server(model)

        # API client'ı güncelle
        self.cfg.MODEL = "LLaMA_CPP"
        self.cfg.BASE_URL = self.cfg.LOCAL_URL
        self.current_model = model
        client.initialize_client()

    def _start_local_model_server(self, model: Model):
        """Yerel model sunucusunu başlat"""
        try:
            # Ollama komutu ile modeli başlat
            cmd = f"chmod +x {model.path} && {model.path}"

            self.current_process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                shell=True,
            )

            # Sunucunun başlamasını bekle
            time.sleep(3)

            # Process'in çalışıp çalışmadığını kontrol et
            if self.current_process.poll() is not None:
                stdout, stderr = self.current_process.communicate()
                raise Exception(f"Model başlatma hatası: {stderr}")

        except Exception as e:
            raise Exception(f"Model sunucusu başlatılamadı: {str(e)}")

    def check_model(self, model_name: str) -> Model:
        """Modeli kontrol et"""
        for model in self.local_models:
            if model.name == model_name:
                return model
        return None

    def _show_download_dialog(self, model: Model) -> bool:
        """Model indirme onayı için diyalog göster"""
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Icon.Question)
        msg_box.setWindowTitle("Model İndir")
        msg_box.setText(
            f"{model.name} modeli yerel olarak bulunamadı. İndirmek ister misiniz?"
        )
        msg_box.setInformativeText(f"Boyut: {model.size} MB")
        msg_box.setStandardButtons(
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        msg_box.setDefaultButton(QMessageBox.StandardButton.Yes)

        response = msg_box.exec()
        return response == QMessageBox.StandardButton.Yes

    def _download_model_with_progress(self, model: Model):
        """Modeli indirme işlemini ilerleme çubuğu ile başlat"""
        progress_dialog = QProgressDialog(
            f"{model.name} indiriliyor...", "İptal", 0, 100
        )
        progress_dialog.setWindowTitle("Model İndiriliyor")
        progress_dialog.setWindowModality(Qt.WindowModality.ApplicationModal)
        progress_dialog.setMinimumDuration(0)
        progress_dialog.setValue(0)

        download_thread = DownloadThread(model)
        download_thread.progress.connect(progress_dialog.setValue)
        download_thread.finished.connect(
            lambda success: self._on_download_finished(success, progress_dialog)
        )
        progress_dialog.canceled.connect(download_thread.terminate)

        download_thread.start()
        progress_dialog.exec()

    def _on_download_finished(self, success: bool, progress_dialog: QProgressDialog):
        """İndirme tamamlandığında çağrılır"""
        progress_dialog.close()
        if success:
            QMessageBox.information(None, "Başarılı", "Model başarıyla indirildi!")
        else:
            QMessageBox.critical(None, "Hata", "Model indirme işlemi başarısız oldu.")
