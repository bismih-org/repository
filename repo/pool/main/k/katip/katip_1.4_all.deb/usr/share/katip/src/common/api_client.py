import sys
from openai import OpenAI
from src.static.config import Config


class APIClient:
    def __init__(self, cfg: Config):
        self.client = None
        self.cfg = cfg
        self.initialize_client()

    def initialize_client(self):
        """API client'ı başlat"""
        try:
            with open(self.cfg.API_KEY_FILE, "r") as file:
                api_key = file.read().strip()
        except FileNotFoundError:
            print(f"{self.cfg.API_KEY_FILE} dosyası bulunamadı!")
            sys.exit(1)

        # OpenAI client'ı Gemini için yapılandır
        self.client = OpenAI(api_key=api_key, base_url=self.cfg.BASE_URL)

    def get_client(self):
        """OpenAI client'ını döndür"""
        return self.client

    # def test_connection(self):
    #     """API bağlantısını test et"""
    #     try:
    #         # Basit bir test mesajı gönder
    #         response = self.client.chat.completions.create(
    #             model="gemini-2.5-flash",
    #             messages=[{"role": "user", "content": "Test"}],
    #             max_tokens=10,
    #         )
    #         return True
    #     except Exception as e:
    #         print(f"API bağlantı testi başarısız: {e}")
    #         return False
