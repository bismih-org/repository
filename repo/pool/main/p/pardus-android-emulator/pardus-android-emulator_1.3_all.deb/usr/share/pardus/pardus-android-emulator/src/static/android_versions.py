android_version={
    "34": "Android 14 beta",
    "33": "Android 13",
    "32": "Android 12",
    "31": "Android 12",
    "30": "Android 11",
    "29": "Android 10",
    "28": "Android 9",
    "27": "Android 8.1",
    "26": "Android 8",
    "25": "Android 7.1",
    "24": "Android 7",
    "23": "Android 6",
    "22": "Android 5.1",
    "21": "Android 5",
}

#* can get from https://github.com/ebelinski/apilevels/blob/main/index.md