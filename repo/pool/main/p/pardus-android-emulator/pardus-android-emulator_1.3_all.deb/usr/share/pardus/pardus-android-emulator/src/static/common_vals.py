class Common_vals:
    lb_subpro_output=None
    lb_dialog_wait_status=None
    prg_bar_process=None
    stck_main=None

    is_thread_running=True #TODO: thread durdurma için bunu ekle
    is_process_running=True

    def __init__(self):pass